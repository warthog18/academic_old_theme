Christophe Basso Circuits and Models
These circuits and models are described in Christophe Basso's book "Switch Mode Power Supplies: SPICE Simulations and Practical Designs".

Installation
Copy all of the .LIB files to the Library folder under the main MC9 folder.  In the Library folder, there is a file called NOM.LIB.  Open this in any text editor and add the following lines (make sure they are not already present):

.lib "smps_cb.lib"
.lib "pwmswitch.lib"
.lib "application.lib"
.lib "power456.lib"
.lib "copec.lib"

The circuit files should be installed to the folder specified by the Data field in the Paths dialog box which can be seen by clicking on the File menu and selecting Paths.

